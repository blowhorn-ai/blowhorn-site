BLOWHORN BRAND KIT
==================

Everything you need to show Blowhorn: the logo, colors, type, the usage
rules, Major Blowhorn, the troops, Old Thunderlung, the scenes and the
launch press graphics. Version 1, October 2026. The guidelines, with
examples, also live at https://blowhorn.ai/brand/

Only want the logo? Get the logo kit at
https://blowhorn.ai/brand/blowhorn-logo-kit.zip


WHAT'S INSIDE

  Blowhorn-brand-guidelines.pdf   The guidelines, seven slides
  logo/                           Lockups, icons, wordmarks, app icons and
                                  favicons, SVG and PNG, light and dark
  colors/                         The palette as JSON, CSS and plain text
  cast/                           Major Blowhorn, Old Thunderlung and the
                                  troops as WebP, one folder per character
  scenes/                         Major and the troops at work, in several
                                  shapes
  press/                          Launch graphics for posts, link cards
                                  and slides
  listing/                        Banners for app directory and connector
                                  listings

Logos come as SVG (svg/, the master: use it when you can) and as
transparent PNG in several sizes (png/, named <file>-<width>.png).
Files ending in -on-dark or -white are for dark grounds.


THE CAST

  cast/major-blowhorn/                             Major Blowhorn, 79 pictures (with cutouts/)
  cast/old-thunderlung/                            Old Thunderlung, 19 pictures (with icons/)
  cast/algorithm-fog/                              Algorithm Fog, 2 pictures (with cutouts/)
  cast/bantam-rooster/                             Bantam rooster, 2 pictures (with cutouts/)
  cast/bot-swarm/                                  Bot Swarm, 2 pictures (with cutouts/)
  cast/bugler-chick/                               Bugler Chick, 2 pictures (with cutouts/)
  cast/buzz-brigade/                               The Buzz Brigade, 2 pictures (with cutouts/)
  cast/captain-gallop/                             Captain Gallop, 2 pictures (with cutouts/)
  cast/chief-drill-instructor/                     Chief Drill Instructor, 18 pictures (with cutouts/)
  cast/clone-army/                                 Clone Army, 2 pictures (with cutouts/)
  cast/colonel-plume/                              Colonel Plume, 2 pictures (with cutouts/)
  cast/corporal-clover/                            Corporal Clover, 5 pictures (with cutouts/)
  cast/corporal-hum/                               Corporal Hum, 2 pictures (with cutouts/)
  cast/corporal-twinstop/                          Corporal Twinstop, 2 pictures (with cutouts/)
  cast/field-manual/                               The Field Manual, 4 pictures
  cast/general/                                    The General, 17 pictures (with cutouts/)
  cast/gi-donkey/                                  GI Donkey, 22 pictures (with cutouts/)
  cast/inspector-whiskers/                         Inspector Whiskers, 2 pictures (with cutouts/)
  cast/keyboard-warrior/                           Keyboard Warrior, 17 pictures (with cutouts/)
  cast/lance-corporal-squeak/                      Lance Corporal Squeak, 2 pictures (with cutouts/)
  cast/mama-pekin-and-the-ducks-in-a-row-brigade/  Mama Pekin and the Ducks-in-a-Row Brigade, 2 pictures (with cutouts/)
  cast/mouse-marine/                               Mouse Marine, 17 pictures (with cutouts/)
  cast/night-watch-officer-hoot/                   Night Watch Officer Hoot, 2 pictures (with cutouts/)
  cast/noise/                                      The Noise, 2 pictures (with cutouts/)
  cast/password-houseguest/                        Password Houseguest, 2 pictures (with cutouts/)
  cast/pigeon-couriers/                            Pigeon Couriers, 2 pictures (with cutouts/)
  cast/platoon-private/                            Platoon Private, 15 pictures (with cutouts/)
  cast/pony-express-private-penny/                 Pony Express Private Penny, 2 pictures (with cutouts/)
  cast/private-fleece/                             Private Fleece, 2 pictures (with cutouts/)
  cast/private-hopkins/                            Private Hopkins, 2 pictures (with cutouts/)
  cast/private-pot-rack/                           Private Pot-Rack, 2 pictures (with cutouts/)
  cast/ranger-kid/                                 Ranger Kid, 2 pictures (with cutouts/)
  cast/recruit-chick/                              Recruit Chick, 30 pictures (with cutouts/)
  cast/robo-recruit/                               Robo-Recruit, 16 pictures (with cutouts/)
  cast/scarecrows/                                 Scarecrows, 2 pictures (with cutouts/)
  cast/scout-biscuit/                              Scout Biscuit, 2 pictures (with cutouts/)
  cast/sergeant-collie/                            Sergeant Collie, 2 pictures (with cutouts/)
  cast/sergeant-mother-hen/                        Sergeant Mother Hen, 2 pictures (with cutouts/)
  cast/sergeant-steady/                            Sergeant Steady, 5 pictures (with cutouts/)
  cast/sleeper-cell/                               Sleeper Cell, 17 pictures (with cutouts/)
  cast/spam-gremlins/                              Spam Gremlins, 2 pictures (with cutouts/)
  cast/staff-sergeant-red-flag/                    Staff Sergeant Red Flag, 5 pictures (with cutouts/)
  cast/supply-mule-sarge/                          Supply Mule Sarge, 2 pictures (with cutouts/)
  cast/trench-trooper/                             Trench Trooper, 18 pictures (with cutouts/)
  cast/wing-commander-vee/                         Wing Commander Vee, 2 pictures (with cutouts/)

Each picture is here once, at full size, as WebP. Most are drawn on a
black stage, and the files in cutouts/ have a transparent ground for
every other ground. Old Thunderlung comes with its red cord and tassels
("tassel", the usual look) and plain ("notassel"), with ready-made
square icons in icons/.


THE SCENES

  scenes/  225 pictures

Each scene is here once, at full size, as WebP. Use a scene whole: don't
crop a character out of it or recombine scenes.


PRESS GRAPHICS

  press/  9 pictures

Ready-made launch graphics in three shapes: square for posts (1080x1080),
link cards (1200x630) and wide slides (1920x1080). Use them as they are.


LISTING BANNERS

  listing/  2 pictures

A listing banner and link card (1200x630) and a 16:9 hero (1600x900). For
the square icon a catalog asks for, use blowhorn-app-icon-square-512.png
in the app-icon folder. Use them as they are.


USING THE LOGO

  Light grounds: blowhorn-lockup-horizontal.svg. Dark grounds: the
  -on-dark file. Teal, photos or anything busy: -mono-charcoal on light,
  -mono-white on dark. Square spaces: the stacked lockup. Where the name is
  already there: the icon. An app directory or connector catalog that
  asks for a square icon: blowhorn-app-icon-square-512.png, in the app-icon
  folder.

  Keep clear space of half the icon's height on every side. Smallest
  sizes: horizontal lockup 96 px wide, stacked 64 px, icon 24 px. Below
  24 px, use the favicon files.

  Please don't recolor, outline, stretch, squash or rotate the logo, add
  shadows, glows or gradients, put the full-color icon on teal, retype the
  wordmark in a font, or rearrange the icon and the wordmark. If it isn't
  in this kit, it isn't the logo.


USING THE COLORS

  Lead with teal and charcoal. Yellow is an accent: under a tenth of any
  layout. For text on light grounds use Teal Deep, not Teal. Text on teal
  or yellow is Near Black, never white. Hex and RGB values are in colors/.


USING THE TYPE

  Display: Bricolage Grotesque, ExtraBold, tight tracking.
  Text: Instrument Sans, 400 to 600.
  Code and labels: JetBrains Mono, 400 and 500.

  All three are free from Google Fonts, under the SIL Open Font License:
  https://fonts.google.com/specimen/Bricolage+Grotesque
  https://fonts.google.com/specimen/Instrument+Sans
  https://fonts.google.com/specimen/JetBrains+Mono
  The logo files don't need any font: every letter is outlined.


USING THE CAST

  One character per page or screen, and one appearance of Major per page.
  Use the pictures as they are, on their black stage or as cutouts.
  Put Major on white, light teal or cream grounds. On bare teal give him a
  cream or yellow disc; on near black, keep his cream keyline.
  Don't recolor, outline, add shadows or texture, rotate, or crop through a
  character.
  Keep the cast away from anything about security, sign-in, billing, legal
  matters or a failed post. Major takes those personally.
  Old Thunderlung is Major's family bugle, not his megaphone. Use the plain
  version where the cord and tassels would be too small or too busy.


THE NAME

  Blowhorn. One word, capital B. In formal copy say Layer5 Blowhorn the
  first time, then Blowhorn. Not BlowHorn, not Blow Horn.


LICENSE

  Blowhorn, the Blowhorn logos, Major Blowhorn, Old Thunderlung and the
  troops are marks and artwork of Layer5, Inc. This kit lets you write
  about Blowhorn and show it as it is, for press, reviews, talks, events
  and partner pages. It doesn't grant a license to use the marks or the
  characters in your own product names, logos, merchandise or ads.

Questions: https://blowhorn.ai/brand/
